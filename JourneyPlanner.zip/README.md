# JourneyPlanner
## ALG erweiterte Aufgabe 4
Umgesetzt von Alexander Dietrich und Selina Brinnich
